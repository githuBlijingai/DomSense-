"""评估器：对一组场景跑 predict，计算模型正确率/置信度，支持前后对比。

用法:
  python scripts/evaluate.py --scenarios data.json --base-url http://localhost:8000
  python scripts/evaluate.py --adversarial --count 4
  python scripts/evaluate.py --scenarios data.json --out before.json
  python scripts/evaluate.py --compare before.json after.json
"""

import argparse
import json
import os
import sys

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from jmd_api import JMDClient, utf8_stdio  # noqa: E402
from generate_questions import builtin_scenarios, adversarial_scenarios, gen_count  # noqa: E402


def predict_all(client: JMDClient, scenarios: list[dict]) -> list[dict]:
    """Run predict on every scenario, return per-scenario evaluation rows."""
    rows = []
    for i, s in enumerate(scenarios):
        try:
            resp = client.predict(s["state_text"], s["actions"])
        except Exception as exc:  # keep the batch alive on single failure
            rows.append({"index": i, "domain": s.get("domain"), "error": str(exc)})
            continue
        choice = resp.get("choice")
        optimal = s.get("optimal_action")
        rows.append({
            "index": i,
            "domain": s.get("domain"),
            "predicted": choice,
            "optimal": optimal,
            "correct": bool(choice is not None and optimal is not None and choice == optimal),
            "confidence": resp.get("confidence"),
            "choice_probs": resp.get("choice_probs"),
            "model_expected_return": resp.get("expected_return_of_choice"),
            "true_expected_return": (s.get("expected_returns") or [None] * len(s["actions"]))[optimal]
            if optimal is not None else None,
        })
    return rows


def summarize(rows: list[dict]) -> dict:
    done = [r for r in rows if "error" not in r]
    correct = sum(1 for r in done if r["correct"])
    confs = [r["confidence"] for r in done if isinstance(r.get("confidence"), (int, float))]
    by_domain: dict[str, list[int]] = {}
    for r in done:
        by_domain.setdefault(r.get("domain") or "unknown", []).append(1 if r["correct"] else 0)
    return {
        "tested": len(rows),
        "errors": len(rows) - len(done),
        "correct": correct,
        "accuracy": round(correct / len(done), 4) if done else None,
        "mean_confidence": round(sum(confs) / len(confs), 4) if confs else None,
        "by_domain": {d: round(sum(v) / len(v), 4) for d, v in by_domain.items()},
    }


def load_scenarios(path: str | None, domain: str | None, count: int | None,
                   adversarial: bool, seed: int | None) -> list[dict]:
    """count=None / <=0 -> 用全部（避免默认 5 把文件里的题截断）。"""
    if path:
        with open(path, "r", encoding="utf-8") as fh:
            scenarios = json.load(fh)
    else:
        scenarios = adversarial_scenarios() if adversarial else builtin_scenarios()
        if domain:
            scenarios = [s for s in scenarios if s.get("domain") == domain]
    if not count or count <= 0 or count >= len(scenarios):
        return scenarios
    return gen_count(scenarios, count, seed)


def main(argv: list[str] | None = None) -> int:
    utf8_stdio()
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-url", default="http://localhost:8000")
    parser.add_argument("--scenarios", help="JSON file with scenario list.")
    parser.add_argument("--domain")
    parser.add_argument("--count", type=int, default=0, help="0 = 全部")
    parser.add_argument("--seed", type=int)
    parser.add_argument("--adversarial", action="store_true")
    parser.add_argument("--out", help="Write {scenarios, rows, summary} to this JSON file.")
    parser.add_argument("--compare", nargs=2, metavar=("BEFORE", "AFTER"),
                        help="Compare two --out files.")
    args = parser.parse_args(argv)

    if args.compare:
        out = {}
        for tag, p in zip(("before", "after"), args.compare):
            with open(p, "r", encoding="utf-8") as fh:
                data = json.load(fh)
            out[tag] = data.get("summary", {})
        b, a = out["before"].get("accuracy"), out["after"].get("accuracy")
        out["delta"] = round(a - b, 4) if isinstance(a, (int, float)) and isinstance(b, (int, float)) else None
        print(json.dumps(out, ensure_ascii=False, indent=2))
        return 0

    scenarios = load_scenarios(args.scenarios, args.domain, args.count, args.adversarial, args.seed)
    client = JMDClient(args.base_url)
    rows = predict_all(client, scenarios)
    summary = summarize(rows)
    report = {"scenarios": scenarios, "rows": rows, "summary": summary}

    if args.out:
        with open(args.out, "w", encoding="utf-8") as fh:
            json.dump(report, fh, ensure_ascii=False, indent=2)
        print(json.dumps({"out": args.out, **summary}, ensure_ascii=False, indent=2))
    else:
        print(json.dumps({"rows": rows, "summary": summary}, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())
