"""JEV+MDP 闭环模板（已内置示例题库，改 RAW / build() 即可复用）。

原为 outputs/jevm_cycle.py，移入技能目录以保证跨会话可用。

JEV+MDP 一轮完整闭环（出题 → 只读测试 → 提交反馈 → 训练 → 复测 → 出 md 报告）。

本轮规则：
  * 20 道全新原创决策题
  * **答案位置随机打乱**（避免模型学到位置先验）
  * **选项数混合**：部分 2 选一、部分 3 选一
运行：
  python jevm_cycle.py               # 完整闭环（含提交反馈与训练）
  python jevm_cycle.py --dry-run     # 只出题 + 只读测试，不写库不训练
"""

import argparse
import json
import os
import random
import sys
import time
from datetime import datetime

sys.path.insert(0, r"C:\Users\Administrator.DESKTOP-VIVLMOS\.workbuddy\skills\jevm-trainer-skill\scripts")
from jmd_api import JMDClient, utf8_stdio  # noqa: E402

OUT = os.getcwd()  # 产出写到当前工作目录
MD = os.path.join(OUT, "JEV+MDP_本轮训练报告.md")
SCEN = os.path.join(OUT, "scenarios.json")

# state, actions(按写题时的原始顺序), 原始最优索引, 成功概率
RAW = [
    dict(domain="medical",
         state="年轻女性半年内第三次尿路感染，每次短程抗生素均有效，无发热、无腰痛。",
         actions=["低剂量抗生素预防", "调整生活习惯加强补水", "进一步做泌尿系统影像检查"],
         opt=0, p=[0.78, 0.60, 0.55]),
    dict(domain="medical",
         state="80岁老人跌倒后髋部疼痛无法负重，急诊X线未见明确骨折，患者可轻度活动。",
         actions=["做MRI进一步检查", "卧床休息观察加镇痛", "做CT检查"], opt=0, p=[0.80, 0.45, 0.62]),
    dict(domain="medical",
         state="慢性乙肝病毒携带者，肝功能正常，病毒载量中等，无任何不适症状。",
         actions=["完善肝纤维化评估后决定是否抗病毒", "定期随访暂不使用抗病毒药", "自行服用保肝类中药"],
         opt=0, p=[0.80, 0.55, 0.35]),
    dict(domain="finance",
         state="退休夫妇主要依靠养老金与存款生活，近年通胀明显侵蚀购买力，"
               "期望保住本金同时尽量跑赢通胀。",
         actions=["配置国债与通胀挂钩债券组合", "全部改存定期存款", "集中买入高股息个股"],
         opt=0, p=[0.75, 0.50, 0.60]),
    dict(domain="finance",
         state="年轻客户手握一笔资金，同时想付买房首付和辞职创业，两者资金需求相当。",
         actions=["先完成买房确保基本盘", "先投入创业博取更大回报", "资金拆分两边各做一半"],
         opt=0, p=[0.72, 0.58, 0.50]),
    dict(domain="finance",
         state="普通投资者没有时间研究个股和基金经理，计划长期持有分享市场增长。",
         actions=["买入宽基ETF长期持有", "追逐去年排名靠前的主动基金", "自己研究挑选个股"],
         opt=0, p=[0.80, 0.60, 0.40]),
    dict(domain="finance",
         state="购买家电需一次性支出，现金完全够用，商家提供免息分期方案。",
         actions=["一次性付清", "选择分期留出现金流"], opt=0, p=[0.75, 0.55]),
    dict(domain="education",
         state="高中生理科成绩突出但语文英语长期拖后腿，面临选科与发展方向选择。",
         actions=["全力冲刺理科优势方向", "保住优势同时补齐文科短板"], opt=1, p=[0.60, 0.78]),
    dict(domain="education",
         state="成年人自学日语半年进展缓慢，一直在背单词与语法，几乎不开口。",
         actions=["改为沉浸式输入加输出练习", "继续沿用背单词语法的方法"], opt=0, p=[0.78, 0.45]),
    dict(domain="customer_support",
         state="同一产品缺陷已导致该客户第三次投诉，前两次均以补偿方式结案。",
         actions=["推动根因修复并主动回访", "继续按次补偿安抚"], opt=0, p=[0.82, 0.50]),
    dict(domain="customer_support",
         state="VIP客户投诉过程中明确提到打算把经历发到社交平台，问题尚未定位清楚。",
         actions=["先给出超预期补偿稳住客户", "先定位并解决技术问题再谈补偿", "直接转给公关处理"],
         opt=1, p=[0.55, 0.78, 0.60]),
    dict(domain="product",
         state="注册转化率持续偏低，团队怀疑注册流程步骤过多导致用户中途放弃。",
         actions=["精简注册步骤", "保留步骤但增加引导说明"], opt=0, p=[0.78, 0.55]),
    dict(domain="product",
         state="新功能上线后日活明显上涨，但次日留存反而下降。",
         actions=["暂停拉新优先定位留存问题", "继续加码拉新做大日活", "直接回滚该功能"],
         opt=0, p=[0.75, 0.50, 0.45]),
    dict(domain="ethical",
         state="发现核心员工私下承接外部私活，已开始影响其本职工作的交付质量。",
         actions=["正式约谈明确边界与整改要求", "直接辞退", "装作不知道"], opt=0, p=[0.78, 0.45, 0.25]),
    dict(domain="ethical",
         state="采集用户位置数据可显著优化路线推荐效果，但涉及明确隐私顾虑。",
         actions=["仅采集最小必要数据并显式授权", "默认开启以最大化体验"], opt=0, p=[0.85, 0.35]),
    dict(domain="operations",
         state="大促预售数据已出，预测订单量将是平日的数倍，供应商产能需提前锁定。",
         actions=["按预测提前备货锁产能", "等实际订单产生后再采购"], opt=0, p=[0.75, 0.55]),
    dict(domain="operations",
         state="某条老旧产线效率明显低于新线，但设备折旧尚未完成，订单仍在排产。",
         actions=["关停并转外包", "改造升级提升效率", "维持现状继续排产"], opt=1, p=[0.55, 0.75, 0.45]),
    dict(domain="operations",
         state="仓库盘点账实差异率连续两季度上升，怀疑出入库环节存在漏记。",
         actions=["提高循环盘点频率定位漏洞", "改为年末一次性大盘点", "全面部署RFID自动采集"],
         opt=0, p=[0.78, 0.50, 0.62]),
    dict(domain="general",
         state="项目deadline逼近，已连续熬夜一周，白天效率明显下降、开始频繁出错。",
         actions=["调整作息并重新拆分排期赶工", "继续熬夜先把项目赶完"], opt=0, p=[0.72, 0.45]),
    dict(domain="general",
         state="独居老人坚持自己住，子女因工作无法每日探望，担心突发情况无人知晓。",
         actions=["安装紧急呼叫与活动监测并定期探望", "接来同住", "完全尊重老人意愿不作安排"],
         opt=0, p=[0.78, 0.60, 0.50]),
]


def build(seed: int = 20260924) -> list[dict]:
    """打乱每题的选项顺序，使正确答案落在随机位置。

    ⚠️ 曾经的 bug：全局 shuffle 目标位置列表时，会让「2 选一」的题拿到 target=2，
    导致 optimal_action 越界 -> 服务端 422 -> 提交循环崩溃。
    正确做法：**先按选项数分组**，再在组内轮转分配 target，保证 target < 选项数。
    """
    rng = random.Random(seed)
    items = RAW[:]

    order = list(range(len(items)))
    rng.shuffle(order)
    targets = [0] * len(items)
    for n in sorted({len(it["actions"]) for it in items}):
        group = [i for i in order if len(items[i]["actions"]) == n]
        for k, idx in enumerate(group):
            targets[idx] = k % n  # 关键：必须 < 该题选项数

    out = []
    for it, target in zip(items, targets):
        n = len(it["actions"])
        old = it["opt"]
        rest = [i for i in range(n) if i != old]
        rng.shuffle(rest)
        order = rest[:target] + [old] + rest[target:]
        probs = it["p"]
        out.append({
            "state_text": it["state"],
            "actions": [it["actions"][i] for i in order],
            "optimal_action": target,
            "transition_probs": [[probs[i], round(1 - probs[i], 4)] for i in order],
            "expected_returns": [round(probs[i], 4) for i in order],
            "domain": it["domain"],
        })
    return out


def preview(scenarios: list[dict]) -> None:
    print("\n===== 本轮 20 道题（答案位置已随机打乱）=====")
    for i, s in enumerate(scenarios, 1):
        n = len(s["actions"])
        print(f"\n[{i}] ({s['domain']}｜{n}选一)")
        print(f"    题干：{s['state_text']}")
        for j, a in enumerate(s["actions"], 1):
            mark = "  ✅Agent正确" if j - 1 == s["optimal_action"] else ""
            print(f"    选项{j}：{a}{mark}")
    print("\n" + "=" * 46 + "\n")


def run_eval(client: JMDClient, scenarios: list[dict]) -> list[dict]:
    rows = []
    for i, s in enumerate(scenarios):
        r = client.predict(s["state_text"], s["actions"])
        rows.append({
            "index": i,
            "predicted": r.get("choice"),
            "optimal": s["optimal_action"],
            "correct": r.get("choice") == s["optimal_action"],
            "confidence": r.get("confidence"),
            "choice_probs": r.get("choice_probs"),
        })
    return rows


def summarize(rows: list[dict]) -> dict:
    c = sum(1 for r in rows if r["correct"])
    conf = [r["confidence"] for r in rows if isinstance(r.get("confidence"), (int, float))]
    return {
        "tested": len(rows),
        "correct": c,
        "accuracy": round(c / len(rows), 4) if rows else None,
        "mean_confidence": round(sum(conf) / len(conf), 4) if conf else None,
    }


def main() -> int:
    utf8_stdio()
    ap = argparse.ArgumentParser()
    ap.add_argument("--dry-run", action="store_true", help="只出题和只读测试")
    ap.add_argument("--base-url", default="http://localhost:8000")
    ap.add_argument("--max-steps", type=int, default=200)
    args = ap.parse_args()

    scenarios = build()
    with open(SCEN, "w", encoding="utf-8") as fh:
        json.dump(scenarios, fh, ensure_ascii=False, indent=2)
    preview(scenarios)

    from collections import Counter
    print("答案位置分布：", dict(sorted(Counter(s["optimal_action"] for s in scenarios).items())))
    print("选项数分布：", dict(Counter(len(s["actions"]) for s in scenarios)), flush=True)

    # 提交前全量校验：
    #   1) optimal_action 不越界  2) 与 expected_returns 最大值位置一致
    for i, s in enumerate(scenarios):
        n = len(s["actions"])
        assert 0 <= s["optimal_action"] < n, f"第{i + 1}题 optimal_action 越界"
        best = max(range(n), key=lambda k: s["expected_returns"][k])
        assert s["optimal_action"] == best, f"第{i + 1}题 optimal_action 与回报不一致"
    print("[validate] 20 题标签校验通过")

    client = JMDClient(args.base_url)
    before_rows = run_eval(client, scenarios)
    before = summarize(before_rows)
    print("[before]", json.dumps(before, ensure_ascii=False), flush=True)

    result = {
        "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        "model_before": client.model_info(),
        "before": before,
        "rows_before": before_rows,
        "scenarios": scenarios,
    }

    if args.dry_run:
        print("[dry-run] 未提交反馈，未训练")
        result["feedback_submitted"] = 0
    else:
        ok, fail = 0, []
        for i, s in enumerate(scenarios):
            try:  # 单点失败不能中断整轮
                client.submit_feedback(
                    state_text=s["state_text"], actions=s["actions"],
                    optimal_action=s["optimal_action"],
                    transition_probs=s["transition_probs"],
                    expected_returns=s["expected_returns"])
                ok += 1
            except Exception as exc:
                fail.append({"index": i, "error": str(exc)})
        print(f"[feedback] submitted {ok}, failed {len(fail)}", flush=True)
        result["feedback_submitted"] = ok
        result["feedback_failures"] = fail

        try:
            tr = client.trigger_training(max_steps=args.max_steps,
                                         run_name=f"cycle20_{time.strftime('%Y%m%d_%H%M%S')}")
            print("[train] triggered:", json.dumps(tr, ensure_ascii=False), flush=True)
            rec = client.wait_for_training(training_id=tr.get("training_id"))
            print("[train] finished:", json.dumps(rec, ensure_ascii=False), flush=True)
            result["training"] = {"trigger": tr, "record": rec}
        except Exception as exc:
            print("[train] failed/skipped:", exc, flush=True)
            result["training"] = {"error": str(exc)}

        after_rows = run_eval(client, scenarios)
        after = summarize(after_rows)
        print("[after]", json.dumps(after, ensure_ascii=False), flush=True)
        result["after"] = after
        result["rows_after"] = after_rows
        result["model_after"] = client.model_info()

    with open(os.path.join(OUT, "cycle_result.json"), "w", encoding="utf-8") as fh:
        json.dump(result, fh, ensure_ascii=False, indent=2)
    print("[done] ->", os.path.join(OUT, "cycle_result.json"))
    return 0


if __name__ == "__main__":
    sys.exit(main())
