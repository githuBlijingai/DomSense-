"""Shared API client and validation utils for JEV+MDP trainer skill.

API-TRAP NOTES (verified 2026-09-24 against http://localhost:8000/openapi.json):
  * There is NO /api/v1/health endpoint -> use /api/v1/admin/model/info as the probe.
  * Training trigger is POST /api/v1/admin/train  (NOT /api/v1/admin/training/trigger).
    Body: {"feedback_ids": [...], "max_steps": 200, "run_name": "..."}
  * GET /api/v1/admin/training-records uses `page` / `page_size` (NOT limit/offset)
    and returns a plain JSON LIST of TrainingRecord (newest first).
  * GET /api/v1/feedback/stats -> {total, unused, threshold, next_training_in,
    last_training_at, last_training_status}
  * Python: the managed CPython has NO `requests`. Use the system interpreter:
    C:\\Users\\Administrator.DESKTOP-VIVLMOS\\AppData\\Local\\Programs\\Python\\Python313\\python.exe
"""

import json
import sys
import time

try:
    import requests
except ModuleNotFoundError:  # pragma: no cover
    sys.stderr.write(
        "[jmd_api] `requests` not installed for this interpreter.\n"
        "Use the system Python: "
        "C:\\Users\\Administrator.DESKTOP-VIVLMOS\\AppData\\Local\\Programs\\Python\\Python313\\python.exe\n"
    )
    raise


def utf8_stdio() -> None:
    """Force UTF-8 stdout/stderr (Windows GBK console would crash on Chinese output)."""
    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8")  # type: ignore[attr-defined]
        except Exception:
            pass


class JMDError(Exception):
    """Raised when a JEV+MDP API call fails."""


class JMDClient:
    """Thin client for the JEV+MDP HTTP backend."""

    def __init__(self, base_url="http://localhost:8000", timeout=120):
        self.base_url = base_url.rstrip("/")
        self.timeout = timeout

    def _url(self, path: str) -> str:
        return f"{self.base_url}{path}"

    def _raise(self, resp: requests.Response) -> None:
        try:
            detail = resp.json()
        except Exception:
            detail = resp.text
        raise JMDError(f"HTTP {resp.status_code}: {detail}")

    def health(self) -> dict:
        """Probe backend liveness. /api/v1/health does NOT exist on this server,
        so /api/v1/admin/model/info is used instead (it also returns model state)."""
        resp = requests.get(self._url("/api/v1/admin/model/info"), timeout=self.timeout)
        if not resp.ok:
            self._raise(resp)
        info = resp.json()
        info["ok"] = True
        return info

    def model_info(self) -> dict:
        resp = requests.get(self._url("/api/v1/admin/model/info"), timeout=self.timeout)
        if not resp.ok:
            self._raise(resp)
        return resp.json()

    def predict(self, state_text: str, actions: list[str]) -> dict:
        payload = {"state_text": state_text, "actions": actions}
        resp = requests.post(self._url("/api/v1/predict"), json=payload, timeout=self.timeout)
        if not resp.ok:
            self._raise(resp)
        return resp.json()

    def submit_feedback(
        self,
        state_text: str,
        actions: list[str],
        optimal_action: int,
        transition_probs: list[list[float]],
        expected_returns: list[float],
    ) -> dict:
        payload = {
            "state_text": state_text,
            "actions": actions,
            "optimal_action": optimal_action,
            "transition_probs": transition_probs,
            "expected_returns": expected_returns,
        }
        resp = requests.post(self._url("/api/v1/feedback"), json=payload, timeout=self.timeout)
        if not resp.ok:
            self._raise(resp)
        return resp.json()

    def stats(self) -> dict:
        resp = requests.get(self._url("/api/v1/feedback/stats"), timeout=self.timeout)
        if not resp.ok:
            self._raise(resp)
        return resp.json()

    def training_records(self, page: int = 1, page_size: int = 20) -> list[dict]:
        """GET /api/v1/admin/training-records -> plain list, newest first."""
        resp = requests.get(
            self._url("/api/v1/admin/training-records"),
            params={"page": page, "page_size": page_size},
            timeout=self.timeout,
        )
        if not resp.ok:
            self._raise(resp)
        data = resp.json()
        if isinstance(data, dict):
            return data.get("records", data.get("items", []))
        return data if isinstance(data, list) else []

    def trigger_training(self, max_steps: int = 200, run_name: str | None = None,
                         feedback_ids: list[int] | None = None) -> dict:
        """POST /api/v1/admin/train -> {"training_id": int, "status": str}"""
        payload = {"max_steps": max_steps}
        if run_name:
            payload["run_name"] = run_name
        if feedback_ids:
            payload["feedback_ids"] = feedback_ids
        resp = requests.post(self._url("/api/v1/admin/train"), json=payload, timeout=self.timeout)
        if not resp.ok:
            self._raise(resp)
        return resp.json()

    def wait_for_training(self, training_id: int | None = None, poll_interval: float = 5.0,
                          max_wait: float = 900.0) -> dict | None:
        """Poll until the target (or newest) training record leaves running/queued."""
        deadline = time.time() + max_wait
        last = None
        while time.time() < deadline:
            records = self.training_records(page=1, page_size=10)
            if records:
                target = None
                if training_id is not None:
                    for r in records:
                        if r.get("id") == training_id:
                            target = r
                            break
                if target is None:
                    target = max(records, key=lambda r: r.get("id", 0))
                last = target
                if target.get("status") in ("completed", "failed", "cancelled", "error"):
                    return target
            time.sleep(poll_interval)
        return last


def load_scenarios(path: str | None, fallback: list[dict]) -> list[dict]:
    """Load scenarios from a JSON file; fall back to the provided defaults."""
    if path:
        with open(path, "r", encoding="utf-8") as fh:
            return json.load(fh)
    return fallback


def to_json(obj, indent: int = 2) -> str:
    return json.dumps(obj, ensure_ascii=False, indent=indent)
