"""JEV+MDP 自治训练主编排器。

工作流:
  status       查看后端 / 模型 / 反馈 / 最近训练记录（只读，不改模型）
  single       单题：predict -> 对比 -> feedback -> (可选)训练
  batch        批量课程：出题 -> 全量 predict -> 逐个 feedback -> 触发训练 -> 复测
  curriculum   循环课程：多轮 batch，每轮对最弱领域密集出题
  adversarial  对抗探测：边界题 predict -> (反馈) -> 训练 -> 复测对比

用法:
  python run_pipeline.py --workflow evaluation --scenarios s.json   # 只读评测（默认）
  python run_pipeline.py --workflow batch --scenarios s.json --feedback --train  # 用户确认后才加这两项
"""

import argparse
import json
import os
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, os.path.join(HERE, "scripts"))

from jmd_api import JMDClient, JMDError, utf8_stdio  # noqa: E402
from generate_questions import (  # noqa: E402
    builtin_scenarios, adversarial_scenarios, gen_count,
)
from evaluate import predict_all, summarize  # noqa: E402

SYS_PY = r"C:\Users\Administrator.DESKTOP-VIVLMOS\AppData\Local\Programs\Python\Python313\python.exe"


def log(msg: str) -> None:
    sys.stderr.write(f"[pipeline] {msg}\n")
    sys.stderr.flush()


def preview_scenarios(scenarios: list[dict], rows: list[dict] | None = None,
                      show_answer: bool = True) -> None:
    """把题目文本 + 编号选项 + 模型选择 打到 stderr，方便人工核对题目质量。"""
    for i, s in enumerate(scenarios):
        row = (rows[i] if rows and i < len(rows) and "error" not in rows[i] else None)
        log(f"题目 {i + 1}/{len(scenarios)}  [{s.get('domain', 'general')}]")
        sys.stderr.write(f"    {s['state_text']}\n")
        for j, a in enumerate(s["actions"], start=1):
            mark = ""
            if show_answer and s.get("optimal_action") == j - 1:
                mark = "  <== 标准答案"
            sys.stderr.write(f"    选项{j}: {a}{mark}\n")
        if row:
            picked = (row["predicted"] + 1) if row.get("predicted") is not None else None
            sys.stderr.write(
                f"    模型选择: 选项{picked} (confidence={row.get('confidence')})"
                f" | {'正确' if row.get('correct') else '错误'}\n"
            )
        elif row is None and rows and i < len(rows):
            sys.stderr.write(f"    [predict 失败] {rows[i].get('error')}\n")
        sys.stderr.flush()


def load_scenarios(path: str | None, domain: str | None, count: int | None,
                   adversarial: bool, seed: int | None) -> list[dict]:
    """从文件加载时 count<=0 表示不截断，避免漏题。"""
    if path:
        with open(path, "r", encoding="utf-8") as fh:
            scenarios = json.load(fh)
    else:
        scenarios = adversarial_scenarios() if adversarial else builtin_scenarios()
        if domain:
            scenarios = [s for s in scenarios if s.get("domain") == domain]
    if not count or count <= 0 or count >= len(scenarios):
        return scenarios
    return gen_count(scenarios, count, seed)


def submit_feedback_batch(client: JMDClient, scenarios: list[dict]) -> dict:
    ok, failed = 0, []
    last = None
    for i, s in enumerate(scenarios):
        try:
            last = client.submit_feedback(
                state_text=s["state_text"],
                actions=s["actions"],
                optimal_action=s["optimal_action"],
                transition_probs=s["transition_probs"],
                expected_returns=s["expected_returns"],
            )
            ok += 1
        except JMDError as exc:
            failed.append({"index": i, "error": str(exc)})
    return {"submitted": ok, "failed": failed, "last_response": last}


def maybe_train(client: JMDClient, do_train: bool, wait: bool, max_steps: int,
                run_name: str | None) -> dict:
    if not do_train:
        return {"training_triggered": False, "training_status": "skipped"}
    try:
        tr = client.trigger_training(max_steps=max_steps, run_name=run_name)
    except JMDError as exc:
        return {"training_triggered": False, "training_status": f"trigger_failed: {exc}"}
    result = {"training_triggered": True, "trigger_response": tr, "training_status": tr.get("status")}
    if wait:
        rec = client.wait_for_training(training_id=tr.get("training_id"))
        result["training_record"] = rec
        result["training_status"] = (rec or {}).get("status", "unknown")
    return result


def workflow_status(client: JMDClient) -> dict:
    try:
        health = client.health()
    except JMDError as exc:
        return {"ok": False, "error": str(exc)}
    stats = client.stats()
    records = client.training_records(page=1, page_size=5)
    return {
        "ok": True,
        "model": health,
        "feedback": stats,
        "ready_to_train": stats.get("unused", 0) >= 1,
        "recent_training": records,
        "python": SYS_PY,
    }


def run_once(client: JMDClient, scenarios: list[dict], do_feedback: bool, do_train: bool,
             wait: bool, max_steps: int, run_name: str | None, preview: bool = True,
             show_answer: bool = True) -> dict:
    before_rows = predict_all(client, scenarios)
    before = summarize(before_rows)
    if preview:
        preview_scenarios(scenarios, before_rows)

    fb = {"submitted": 0, "failed": [], "last_response": None}
    if do_feedback:
        fb = submit_feedback_batch(client, scenarios)

    tr = maybe_train(client, do_train, wait, max_steps, run_name)

    after = None
    after_rows = None
    if tr.get("training_triggered") and tr.get("training_status") == "completed":
        after_rows = predict_all(client, scenarios)
        after = summarize(after_rows)

    return {
        "scenarios_generated": len(scenarios),
        "scenarios_tested": before["tested"],
        "feedbacks_submitted": fb["submitted"],
        "feedback_failures": fb["failed"],
        "before": before,
        "after": after,
        "before_after_comparison": (
            {"before_accuracy": before["accuracy"],
             "after_accuracy": (after or {}).get("accuracy"),
             "delta": round((after or {}).get("accuracy", 0) - before["accuracy"], 4)
             if after else None}
        ),
        **{k: v for k, v in tr.items()},
    }


def main(argv: list[str] | None = None) -> int:
    utf8_stdio()
    parser = argparse.ArgumentParser(description=__doc__,
                                     formatter_class=argparse.RawDescriptionHelpFormatter)
    parser.add_argument("--workflow", default="evaluation",
                        choices=["status", "evaluation", "single", "batch", "curriculum",
                                 "adversarial"])
    parser.add_argument("--base-url", default="http://localhost:8000")
    parser.add_argument("--scenarios", help="手写出题 JSON 文件路径（优先于内置题）")
    parser.add_argument("--domain")
    parser.add_argument("--count", type=int, default=0, help="0 = 全部（避免截断文件里的题）")
    parser.add_argument("--cycles", type=int, default=3, help="curriculum 轮数")
    parser.add_argument("--seed", type=int)
    parser.add_argument("--feedback", dest="do_feedback", action="store_true",
                        help="提交反馈（默认否 —— 须用户明确确认后才开启）")
    parser.add_argument("--train", dest="do_train", action="store_true",
                        help="提交反馈后触发训练（默认否，避免污染模型）")
    parser.add_argument("--max-steps", type=int, default=200)
    parser.add_argument("--run-name")
    parser.add_argument("--no-wait", action="store_true", help="不等待训练完成")
    parser.add_argument("--no-preview", action="store_true", help="不打印题目/选项预览")
    parser.add_argument("--hide-answer", action="store_true", help="预览里不标注标准答案")
    parser.add_argument("--report", help="把最终报告写入 JSON 文件")
    args = parser.parse_args(argv)

    client = JMDClient(args.base_url)
    started = time.time()

    try:
        if args.workflow == "status":
            report = {"workflow": "status", **workflow_status(client)}
        elif args.workflow == "evaluation":
            scenarios = load_scenarios(args.scenarios, args.domain, args.count, False, args.seed)
            log(f"loaded {len(scenarios)} scenarios (read-only evaluation)")
            report = {"workflow": "evaluation",
                      **run_once(client, scenarios, False, False, False, args.max_steps,
                                 None, not args.no_preview, not args.hide_answer)}
        elif args.workflow in ("single", "batch"):
            n = 1 if args.workflow == "single" else args.count
            scenarios = load_scenarios(args.scenarios, args.domain, n, False, args.seed)
            log(f"loaded {len(scenarios)} scenarios")
            report = {"workflow": args.workflow,
                      **run_once(client, scenarios, args.do_feedback, args.do_train,
                                 not args.no_wait, args.max_steps, args.run_name,
                                 not args.no_preview, not args.hide_answer)}
        elif args.workflow == "adversarial":
            scenarios = load_scenarios(args.scenarios, args.domain, args.count, True, args.seed)
            log(f"loaded {len(scenarios)} adversarial scenarios")
            report = {"workflow": "adversarial",
                      **run_once(client, scenarios, args.do_feedback, args.do_train,
                                 not args.no_wait, args.max_steps,
                                 args.run_name or f"adversarial_{time.strftime('%Y%m%d-%H%M%S')}",
                                 not args.no_preview, not args.hide_answer)}
        else:  # curriculum
            cycles = []
            for c in range(args.cycles):
                log(f"cycle {c + 1}/{args.cycles}")
                domain = args.domain
                if not domain and cycles:
                    weakest = min(cycles[-1]["before"]["by_domain"].items(),
                                  key=lambda kv: kv[1])[0] if cycles[-1]["before"]["by_domain"] else None
                    domain = weakest
                scenarios = load_scenarios(args.scenarios, domain, args.count, False,
                                           (args.seed or 0) + c)
                cycles.append(run_once(client, scenarios, args.do_feedback, args.do_train,
                                       not args.no_wait, args.max_steps,
                                       f"{args.run_name or 'curriculum'}_c{c + 1}",
                                       not args.no_preview, not args.hide_answer))
                cycles[-1]["cycle"] = c + 1
                cycles[-1]["domain"] = domain
            report = {
                "workflow": "curriculum",
                "cycles": cycles,
                "scenarios_generated": sum(c["scenarios_generated"] for c in cycles),
                "feedbacks_submitted": sum(c["feedbacks_submitted"] for c in cycles),
                "first_accuracy": cycles[0]["before"]["accuracy"],
                "last_accuracy": cycles[-1]["after"]["accuracy"] if cycles[-1].get("after")
                else cycles[-1]["before"]["accuracy"],
            }
    except JMDError as exc:
        report = {"workflow": args.workflow, "ok": False, "error": str(exc)}

    report["elapsed_sec"] = round(time.time() - started, 2)
    text = json.dumps(report, ensure_ascii=False, indent=2)
    print(text)
    if args.report:
        with open(args.report, "w", encoding="utf-8") as fh:
            fh.write(text)
    return 0 if report.get("ok", True) else 1


if __name__ == "__main__":
    sys.exit(main())
