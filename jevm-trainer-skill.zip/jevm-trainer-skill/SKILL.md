---
name: jevm-trainer-skill
description: >-
  面向 JEV+MDP（RLCD-MDP）模型的自治训练技能。Agent 自动完成：
  领域出题 → 模型预测评估 → 反馈修正 → 提交训练的全流程。
  支持单题训练、批量课程、对抗探测、循环评估。
  依赖 JEV+MDP Web 后端（默认 http://localhost:8000）。
license: MIT
metadata:
  author: JEV+MDP
  version: 1.0.0
  created: 2026-09-24
  last_reviewed: 2026-09-24
  review_interval_days: 90
  dependencies:
    - url: http://localhost:8000
      name: JEV+MDP API
      type: api
  schema_expectations:
    - url: http://localhost:8000/api/v1/predict
      method: POST
      expected_keys:
        - choice
        - choice_probs
        - transition_probs
        - expected_returns
        - confidence
    - url: http://localhost:8000/api/v1/feedback
      method: POST
      expected_keys:
        - feedback_id
        - accumulated_count
        - will_trigger_training
    - url: http://localhost:8000/api/v1/admin/training-records
      method: GET
      expected_keys:
        - id
        - status
        - num_samples
        - best_val_loss
---
# /jevm-trainer-skill — JEV+MDP 模型自治训练

You are a reinforcement-learning curriculum designer and model trainer for the JEV+MDP (RLCD-MDP) decision system. Your job is to autonomously improve the model by generating relevant decision scenarios, testing the model's choices, providing corrective feedback, and triggering training cycles.

## 工作前提

- JEV+MDP 后端运行在 `http://localhost:8000`（可通过 `--base-url` 指定）
- 模型是一个逐动作打分架构的 RLCD-MDP 模型，`num_outcomes=2`（二元结果），transition_probs 每动作是 `[p_success, p_failure]` 二元概率向量
- 你可以在当前会话中访问任何领域知识来生成题目

## 运行方式（本机已验证 2026-09-24）

**必须用系统 Python**（托管 Python 没装 `requests`，会 ModuleNotFoundError）：

```
C:\Users\Administrator.DESKTOP-VIVLMOS\AppData\Local\Programs\Python\Python313\python.exe
```

工作目录：`C:\Users\Administrator.DESKTOP-VIVLMOS\.workbuddy\skills\jevm-trainer-skill`

| 目的 | 命令 |
|------|------|
| 看状态（只读） | `python run_pipeline.py --workflow status` |
| **只读评测**（默认，推荐先跑这个） | `python run_pipeline.py --workflow evaluation --scenarios s.json` |
| 批量课程 | `python run_pipeline.py --workflow batch --domain medical --count 5 --feedback` |
| 批量 + 训练 | `python run_pipeline.py --workflow batch --scenarios s.json --feedback --train` |
| 循环课程 | `python run_pipeline.py --workflow curriculum --cycles 3 --count 4 --feedback --train` |
| 对抗探测 | `python run_pipeline.py --workflow adversarial --count 4` |
| 单题 | `python run_pipeline.py --workflow single --domain finance` |
| 出题器单独用 | `python scripts/generate_questions.py --domain medical --count 3 --json` |
| 评估器单独用 | `python scripts/evaluate.py --scenarios x.json --out before.json` |

> **默认只读**：既**不提交反馈**也**不触发训练**。写操作必须显式加 `--feedback` / `--train`，
> 且只能在用户明确同意后加（见「用户约定 ②」）。`--count` 传 0 或省略表示不截断。

## Trigger

User invokes `/jevm-trainer-skill` followed by their instruction:

```
/jevm-trainer-skill Generate 3 medical diagnosis scenarios and train the model on them
/jevm-trainer-skill Run a full training cycle: 5 scenarios in finance domain, feedback, train
/jevm-trainer-skill Probe the model with adversarial edge cases and evaluate before/after
/jevm-trainer-skill --domain education --count 10 --cycles 3  Full curriculum training
/jevm-trainer-skill Monitor training status and trigger if threshold is met
/jevm-trainer-skill Check current model stats and report training readiness
```

## 领域出题方法论

生成题目必须遵循 JEV+MDP 模型的决策结构。每个题目是一个**多选项决策场景**，形式为：

### 数据格式

每一道题 = 一个 `Scenario` 字典：
```json
{
  "state_text": "描述决策场景的文本（~50-150字），包含上下文、可选背景",
  "actions": ["选项A描述", "选项B描述", ...],
  "optimal_action": 0,         // 正确动作的索引（0-based）
  "transition_probs": [        // 每个动作的二元结果概率
    [0.85, 0.15],              // 选动作0 → success=85%, failure=15%
    [0.40, 0.60],
    [0.65, 0.35]
  ],
  "expected_returns": [0.85, 0.40, 0.65],   // 期望回报（success 率）
  "domain": "medical"          // 领域标签
}
```

### 设计原则（必读）

1. **state_text 必须有决策张力**：不是陈述事实，而是让人/模型必须在选项中做出权衡。例如 "一位55岁患者同时有高血压和轻度肾损伤，需要选择降压药，现有三种方案……"
2. **每个动作必须是合理选项**：不能出现明显错误选项。所有选项在某个维度上都有道理。
3. **optimal_action 是"最优"而非"唯一正确"**：给定 transition_probs，最优动作是期望回报最高的那个。期望回报 = success_prob。
4. **transition_probs 反映动作的风险-回报特征**：
   - 高回报高风险的 action：`[0.9, 0.1]` 虽 success 率高，但若失败代价极大
   - 稳妥型 action：`[0.6, 0.4]` 中庸但可靠
   - 探索型 action：`[0.3, 0.7]` 风险大但可能带来新信息
5. **expected_returns = transition_probs[0] = success_prob**（对于二元 outcome，期望回报直接等于 success 概率）
6. **选项数**：2-5 个，推荐 3 个以充分利用模型能力

### 领域模板

| 领域 | 示例场景 | 典型选项数 |
|------|---------|-----------|
| medical | 治疗方案选择、药物优先级、诊断路径 | 3-4 |
| finance | 投资组合配置、风险评估、交易策略 | 2-4 |
| education | 教学方案选择、学习路径推荐 | 2-3 |
| customer_support | 工单优先级、响应策略选择 | 2-3 |
| product | 功能优先级排序、发布策略选择 | 2-4 |
| ethical | 伦理困境决策、资源分配 | 2-3 |
| operations | 供应链优化、调度方案选择 | 2-4 |
| general | 日常决策、资源配置、路径规划 | 2-3 |

### 对抗探测场景

用于测试模型边界的不寻常决策场景：
- **信息缺失**：某些选项信息不全，模型需处理不确定性
- **期望值相等**：所有选项期望回报相同但方差不同
- **三难困境**：三个维度上的三个选项各有利弊
- **反转偏好**：默认最优随条件改变

## API 使用方法

所有脚本通过 `requests` 库调用 JEV+MDP HTTP API。

### 核心 endpoints

| 端点 | 方法 | 用途 |
|------|------|------|
| `/api/v1/predict` | POST | 获取模型对一组选项的决策 |
| `/api/v1/feedback` | POST | 提交正确决策作为训练反馈 |
| `/api/v1/feedback/stats` | GET | 查看已积累反馈数 |
| `/api/v1/admin/train` | POST | 手动触发一次训练 |
| `/api/v1/admin/training-records` | GET | 查看训练记录（`page`/`page_size`，返回**数组**） |
| `/api/v1/admin/model/info` | GET | 模型版本/参数/val_loss（**兼作 health 探针**） |

### ⚠️ API 陷阱（踩过的坑，勿再犯）

1. **没有 `/api/v1/health`** —— 返回 404。探活用 `/api/v1/admin/model/info`。
2. **训练触发是 `POST /api/v1/admin/train`**，不是 `/admin/training/trigger`。
   请求体 `{"max_steps": 200, "run_name": "...", "feedback_ids": [...]}`（全部可选）。
3. **`training-records` 参数是 `page` / `page_size`**（不是 limit/offset），返回**裸数组**，最新在前。
4. `feedback/stats` 返回 `{total, unused, threshold, next_training_in, last_training_at, last_training_status}`；`unused>=1` 才值得触发训练。
5. Windows 控制台 GBK，脚本必须 `utf8_stdio()` 否则中文输出 UnicodeEncodeError。
6. 托管 Python 无 `requests`，见上方「运行方式」。

### predict 请求/响应

**请求体**：
```json
{"state_text": "场景描述", "actions": ["选项A", "选项B", "选项C"]}
```

**响应体**：
```json
{
  "choice": 2,
  "choice_label": "选项C",
  "choice_probs": [0.25, 0.30, 0.45],
  "transition_probs": [[0.80, 0.20], [0.70, 0.30], [0.85, 0.15]],
  "expected_returns": [0.80, 0.70, 0.85],
  "confidence": 0.87,
  "compact_output": {...}
}
```

### feedback 请求体

```json
{
  "state_text": "场景描述",
  "actions": ["选项A", "选项B", "选项C"],
  "optimal_action": 0,
  "transition_probs": [[0.85, 0.15], [0.40, 0.60], [0.65, 0.35]],
  "expected_returns": [0.85, 0.40, 0.65]
}
```

## 完整工作流

### 工作流 1：单题训练

```
出题 → predict 获取模型决策 → 对比 optimal → 提交 feedback → 检查 stats → 可选触发训练
```

通过 `run_pipeline.py` 的 `--workflow single` 模式执行。

### 工作流 2：批量课程

```
生成 N 道题 → 批量 predict → 逐个提交 feedback → 检查训练门槛 →
触发训练 → 等待完成 → 验证训练后决策改善
```

通过 `run_pipeline.py` 的 `--workflow batch` 模式执行，是主要的工作流。

### 工作流 3：对抗探测

```
生成对抗场景 → predict 获取模型在当前这些边界案例上的表现 →
提交反馈（可选）→ 触发训练 → 重新 predict → 对比前后改善
```

通过 `scripts/evaluate.py --adversarial` 执行。

### 工作流 4：循环课程训练

```
for cycle in range(cycles):
    生成新题目 → predict → 评估模型当前能力 →
    对最弱领域密集出题 → 批量反馈 → 触发训练 → 等待完成
```

通过 `run_pipeline.py` 的 `--workflow curriculum --cycles 3` 执行。

## 出题硬规则（必须遵守，血的教训）

1. **答案位置必须随机打乱**，且要在所有位置上大致均衡。
   - 反例：早期题集中 40/60 题的正确答案都在选项1，导致「永远选选项1」的常数策略
     就能拿 66.7%，而模型偏学成了「偏好选项3」，所有正确率数字全部失真。
2. **打乱时必须按选项数分组再轮转**：
   ```python
   # ✅ 正确：target 一定 < 该题选项数
   for n in sorted({len(it["actions"]) for it in items}):
       group = [i for i in order if len(items[i]["actions"]) == n]
       for k, idx in enumerate(group):
           targets[idx] = k % n
   # ❌ 错误：全局 shuffle 目标列表，会让 2 选一题拿到 target=2（越界）
   ```
   **后果**：`optimal_action` 越界 → 服务端 422 → 提交循环崩溃 → 整轮白跑。
3. **提交前全量断言校验**（必做）：
   ```python
   assert 0 <= s["optimal_action"] < len(s["actions"])
   assert s["optimal_action"] == max(range(n), key=lambda k: s["expected_returns"][k])
   assert len(s["transition_probs"]) == n == len(s["expected_returns"])
   ```
4. **选项数要混合**（部分 2 选一、部分 3 选一），否则模型会学到固定的选项数量先验。
5. **提交循环套 try/except**，单点失败记录并继续，不要中断整轮。

## 最佳实践（实测得出）

- **`--count` 传文件或设为 0**：CLI 默认 count=5，会把文件里加载的题截断（踩过坑：20 题只跑了 5 题）。
- **训练后必须用留出集复测**：拿训练过的题复测会虚高。
  实测：20 题训练后 45%→65%（+20pp），但 10 道全新留出题只有 50%（随机基线约 35%），
  说明存在记忆效应。正确做法是每轮另出一批新题做 held-out 评估。
- **看 val_loss 而不是只看正确率**：21 条样本训练后 best_val_loss 由 1.1104 升到 1.1661（变差），
  但正确率却涨了 20pp —— 样本太少时正确率会骗人。
- 反馈提交后 `unused` 清零，需继续投喂到 threshold（默认 50）才会自动训练。
- **⚠️ 后端会自动训练**：当 `unused >= threshold(50)` 时服务端自动起训练任务，
  此时手动 `POST /api/v1/admin/train` 会返回 **`HTTP 409 已有训练任务在运行`**。
  处理：捕获 409 → 轮询 `training-records` 等现有任务完成后再评估，不要重复触发。
- **样本内指标不可信**：拿参与训练的题目复测必然虚高（实测 45%→75%）。
  每轮必须准备**未参与训练的新题**做留出集；留出集至少 30 题（10 题噪声太大，
  1 题就占 10 个百分点）。
- **看模型的选项位置分布**：若预测高度集中在某个位置，说明它学的是位置先验而非语义。
- **同时盯 val_loss**：val_loss 下降 + 留出集提升，才算真的学到东西。

## 完整闭环模板（推荐）

`outputs/jevm_cycle.py` + `outputs/finish_cycle.py` 是一套可直接复用的闭环：

```
python jevm_cycle.py            # 出题（位置打乱/选项数混合）+ 校验 + 只读测试 + 反馈 + 训练
python jevm_cycle.py --dry-run  # 只出题和只读测试
python finish_cycle.py          # 标签纠偏 + 补提交 + 训练 + 复测 + 出 md 报告
```

报告里必须写清：数据设计（位置分布/选项数分布）、训练前后对比、
**并标注这是样本内还是留出集结果**、过程中的事故与修复。

## 输出格式

所有脚本输出结构化的 JSON 到 stdout；summary 在最后；错误信息到 stderr。管道编排器（run_pipeline.py）将每个步骤的输出收集为 Python 字典，最后一次性打印最终报告。

### 用户约定（必须遵守）

**① 先出题给用户看**：每次跑训练/评测，都要把题目原文和编号选项（选项1 / 选项2 / 选项3）报给用户，不能只丢一个正确率数字。

**② 评测完成后必须先询问，禁止自动提交反馈/训练**（最高优先级规则）：
- 默认行为是**只读评测**（`predict` + 评估），不得写入任何反馈、不得触发训练。
- 评测报告给出后，必须停下来问用户：是否要把这批数据的正确答案提交为反馈并做反向训练？
- 只有用户明确同意（"是/继续/提交/训练"）后，才执行 `feedback` → `train`。
- 反过来，用户明确说"不用/先别训练"时不得擅自提交。
- CLI 层面已配合：反馈需显式 `--feedback` 开启，训练需显式 `--train` 开启。

所以标准流程永远是：**出题 → 展示题目给看 → 只读评测 → 出示报告 → 【询问用户】→ 用户点头后才 feedback + train → 留出集复测 → 再报告。**
`run_pipeline.py` 默认已在 stderr 打印题目预览，格式如下：

```
[pipeline] 题目 1/1  [medical]
    一位55岁患者同时患有高血压和轻度肾功能不全……
    选项1: 氨氯地平
    选项2: 缬沙坦  <== 标准答案
    选项3: 双氢克尿噻
    模型选择: 选项2 (confidence=0.4314) | 正确
```

相关开关：`--no-preview`（关预览）、`--hide-answer`（预览里不标答案，用于盲测）。
在最终回复里应把「题干 + 选项1/2/3 + 模型选了哪个 + 对不对」复述给用户。

最终报告包含：
- `workflow`: 执行的工作流类型
- `scenarios_generated`: 生成的场景数量
- `scenarios_tested`: 测试的场景数量
- `feedbacks_submitted`: 提交的反馈数量
- `training_triggered`: 是否触发了训练
- `training_status`: 训练结果（completed/failed/skipped）
- `before_after_comparison`（可选）: 训练前后的决策正确率对比
